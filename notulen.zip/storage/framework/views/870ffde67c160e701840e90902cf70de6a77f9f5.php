
<ul class="nav nav-tabs justify-content-center">
    
    <li class="nav-item">
    <a class="nav-link <?php echo e(($navnote == 'all') ?  'active fw-bold text-uppercase'  : 'text-secondary'); ?>"  href="/notes">All</a>
    </li>
    
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
        
        <li class="nav-item">
        <a class="nav-link <?php echo e(($navnote == 'alltrash') ?  'active fw-bold'  : 'text-secondary'); ?>" href="/note/alltrash">Trash</a>
        </li>  
    <?php endif; ?>
</ul><?php /**PATH E:\Laravel-app\project1\resources\views/user/adminnav.blade.php ENDPATH**/ ?>