<div class="card mb-3 shadow-sm small <?php echo e((!count($note->readHistories->where('user_id', auth()->user()->id))) ? 'border-danger' : ''); ?>" >

    
    <div class="card-header bg-secondary text-white small justify-content-between">
        <div class=" d-flex justify-content-between">
            <div>
        <?php if($note->user): ?>
            Oleh <a href="/users/<?php echo e($note->user->slug); ?>" class="text-decoration-none text-white"><?php echo e($note->user->name); ?></a>  
     
        <?php else: ?>
            Ditulis oleh Anonim 
        <?php endif; ?> 
        
            <?php if(!count($note->readHistories)): ?>
                <span class="badge bg-danger text-white ">BARU</span>
            <?php endif; ?>
        
        
            <span class="badge bg-danger text-white ">BARU</span>
        
    </div>
        <div>
            <small><?php echo e($note->created_at->diffForHumans()); ?></small>
          </div>
      </div>
    </div>
    

    <a href="/notes/<?php echo e($note->slug); ?>" class="text-decoration-none text-reset">
    <div class="card-body small">
    <h6 class="card-title "> 
        <?php echo e($note['judul']); ?>

        <?php if(count($note->updateHistories)): ?>
        <span class="badge bg-info text-white text-small">Diedit <?php echo e(count($note->updateHistories)); ?> kali</span>
        <?php endif; ?>
    </h6>

   

    <p class="card-subtitle  mb-2 "> <?php echo e($note->pemimpin); ?>, pada <?php echo e(App\Http\Controllers\NoteController::tanggal_indo($note->tanggal, true)); ?></p>


    
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('restore', $note)): ?>
            <a href="/notes/restore/<?php echo e($note->slug); ?>" class="btn btn-success btn-sm small" onclick="return confirm('Anda yakin ingin merestore Note ini?')">Restore Note</a>  
        <?php endif; ?> 
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('forceDelete', $note)): ?>
            <a href="/notes/forceDelete/<?php echo e($note->slug); ?>" class="btn btn-danger btn-sm" onclick="return confirm('Anda yakin ingin menghapus permanen Note ini?')">Delete Permanent</a>
        <?php endif; ?>
    

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $note)): ?>
            <a href="/notes/<?php echo e($note['slug']); ?>/edit" class="btn btn-sm btn-info"><small> Ubah</small></a>  
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $note)): ?>
            <form action="/notes/<?php echo e($note->id); ?>" method="POST" class="d-inline">
                <?php echo method_field('delete'); ?>
                <?php echo csrf_field(); ?>
                <button class="btn btn-danger btn-sm" onclick="return confirm('Anda yakin ingin menghapus Note ini?')"><small>Hapus</small></button>
            </form>
        <?php endif; ?>
</div><?php /**PATH E:\Laravel-app\project1\resources\views/note/noteitem.blade.php ENDPATH**/ ?>