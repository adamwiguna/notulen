



<?php $__env->startSection('container'); ?>



        <?php if(session()->has('success')): ?>
          <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>   
        <?php endif; ?>
        

        <?php $__currentLoopData = $notes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class=" border mb-2 pb-2">
            <a href="/notes/<?php echo e($note->slug); ?>" class=" text-decoration-none">
                <div class="text-start mx-3 my-1 text-dark"><?php echo e($note->judul); ?></div>
            </a>
        <div class="container">
            <div class="row row-cols-3 justify-content-start">
                <?php $__currentLoopData = $note->noteImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e($image->image_url); ?>" class="m-0 p-0">
                <img class=" img-thumbnail p-1" src="<?php echo e($image->image_url); ?>" alt="" style="width: 115px; height: 115px">
                </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>   
        </div>   
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel-app\project1\resources\views/galleries/index.blade.php ENDPATH**/ ?>