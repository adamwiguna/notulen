


<?php $__env->startSection('container'); ?>

<?php if(session()->has('success')): ?>

<?php endif; ?>



<div class="card mb-5">
    <div class="card-header">
      <ul class="nav nav-tabs card-header-tabs">
        <li class="nav-item">
          <a class="nav-link " href="/notes/<?php echo e($notes->slug); ?>">Note</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/notes/images/<?php echo e($notes->slug); ?>">Foto</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" href="/notes/attendances/<?php echo e($notes->slug); ?>">Peserta</a>
        </li>
      </ul>
    </div>
    <div class="card-body">
  
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('addAttendances', $notes)): ?>
        <div>
            <form action="/notes/attendances/simpan" method="POST">
              <?php echo csrf_field(); ?>
              <div class="input-group input-group-sm mb-3">
                <input type="hidden"  name="note_id" id="" value="<?php echo e($notes->id); ?>">
                <input type="hidden"  name="note_slug" id="" value="<?php echo e($notes->slug); ?>">
                  <input type="text" class="form-control form-control-sm" placeholder="Nama" name="nama" id="nama" aria-label="Recipient's username" aria-describedby="basic-addon2" value="<?php echo e(old('nama')); ?>">
                  <input type="text" class="form-control form-control-sm" placeholder="Instansi" name="instansi" id="instansi" aria-label="Recipient's username" aria-describedby="basic-addon2" value="<?php echo e(old('instansi')); ?>">
                  <div class="input-group-append">
                    <button class="btn btn-sm btn-success" type="submit"><i class="bi bi-plus-square"></i></button>
                  </div>
              </div>
            </form>
        </div>
      <?php endif; ?>
  


      <div class="list-user">
        <table class="table table-sm table-borderless">
            <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col">Nama</th>
                <th scope="col">Instansi</th>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('deleteAttendances', $notes)): ?>
                <th scope="col">Aksi</th>
                <?php endif; ?>
              </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $attendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <th scope="row"><?php echo e($loop->iteration); ?></th>
                        <td><?php echo e($attendance->nama); ?></td>
                        <td><?php echo e($attendance->instansi); ?></td>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('deleteAttendances', $notes)): ?>
                        <td>
                            
                            <form action="/notes/attendances/<?php echo e($attendance->id); ?>" method="POST" class="d-inline">
                                <?php echo method_field('delete'); ?>
                                <?php echo csrf_field(); ?>
                                <button class="btn btn-danger btn-sm" onclick="return confirm('Anda yakin ingin menghapus Note ini?')"><i class="bi bi-trash"></i></button>
                            </form>
                        </td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <th scope="row">-</th>
                        <td>-</td>
                        <td>-</td>
                        <td>-</td>
                <?php endif; ?>
            </tbody>
          </table>    
    </div>
      
    </div>
  </div>

  
            
      
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel-app\project1\resources\views/note/singlenote_attendances.blade.php ENDPATH**/ ?>