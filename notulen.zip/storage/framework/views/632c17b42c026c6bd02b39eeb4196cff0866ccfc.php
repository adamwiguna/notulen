



<?php $__env->startSection('container'); ?>
<?php if(session()->has('success')): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
  <?php echo e(session('success')); ?>

  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>   
<?php endif; ?>

<div class="list-user mb-5">
  <table class="table table-sm table-borderless mb-lg-5">
      <tbody>
          <?php $__currentLoopData = $histories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <?php if($history->user): ?>
                <td>  [<?php echo e($history->created_at); ?>] <text class="text-danger"> <?php echo e($history->user->name); ?> </text>  <?php echo e($history->status); ?> <text class="text-info"><?php echo e($history->noteWithTrashed->judul ?? $history->note_id); ?></text></td>

                <?php endif; ?>
              </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>    
</div>      

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel-app\project1\resources\views/history/index.blade.php ENDPATH**/ ?>