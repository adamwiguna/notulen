


<?php $__env->startSection('container'); ?>

    <p class="text-dark">
        <a href="/notes/create/form" class="btn btn-primary btn-sm ms-auto"><i class="bi bi-file-earmark-plus"></i> Buat Notes Baru </a>
    </p> 

<?php echo $__env->make('user.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        <?php if(session()->has('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>   
        <?php endif; ?>
    
        <div class="row">
            <div class="col">
                <form action="/notes">
                    <div class="input-group mb-3">
                        <input type="text" class="form-control" placeholder="Cari" name="cari" value="<?php echo e(request('cari')); ?>">
                        <div class="input-group-append">
                          <button class="btn btn-outline-secondary" type="submite">Cari</button>
                        </div>
                      </div>
                </form>
            </div>
        </div>
        
        <div class="list-note bg-white">

            <?php if($notes->count()): ?>
          
            <?php $__currentLoopData = $notes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
                <div class="card mb-3 shadow-lg" >
                    <div class="card-body">
                    <h5 class="card-title"> <text class="text-danger"> BARU </text><?php echo e($note->id); ?><?php echo e($note['judul']); ?></h5>

                    <h6 class="card-subtitle mb-2"> <?php echo e($note['keterangan']); ?></h6>

                    <?php if($note->user): ?>
                    <p class="card-text">
                        Ditulis oleh <a href="/users/<?php echo e($note->user->slug); ?>"><?php echo e($note->user->name); ?></a>  pada tanggal <?php echo e($note['tanggal']); ?>

                    </p>
                    <?php else: ?>
                        <p class="card-text">
                            Ditulis oleh Anonim pada tanggal <?php echo e($note['tanggal']); ?>

                        </p>
                    <?php endif; ?> 
                    
                    <a href="/notes/<?php echo e($note['slug']); ?>" class="btn btn-primary">Lihat Detail</a>  
                    </div>
                </div>  
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
            Tidak ada Note
            <?php endif; ?>
            
            <div class="d-flex justify-content-center  mb-5">
                <?php echo e($notes->onEachSide(0)->links()); ?>

            </div>

    
        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel-app\project1\resources\views/note/list_new.blade.php ENDPATH**/ ?>