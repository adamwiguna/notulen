


<?php $__env->startSection('container'); ?>



<div class="card mb-5">

    <div class="card-header">
      <ul class="nav nav-tabs card-header-tabs">
        <li class="nav-item">
          <a class="nav-link active" href="/notes/<?php echo e($notes->slug); ?>">Note</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/notes/images/<?php echo e($notes->slug); ?>">Foto</a>
        </li>
        <li class="nav-item">
          <a class="nav-link " href="/notes/attendances/<?php echo e($notes->slug); ?>">Peserta</a>
        </li>
      </ul>
    </div>

    <div class="card-body">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $notes)): ?>
          <a href="/notes/<?php echo e($notes['slug']); ?>/edit" class="btn btn-info btn-sm mb-3"><i class="bi bi-pencil-square"></i> Ubah </a>  
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $notes)): ?>
          <form action="/notes/<?php echo e($notes->id); ?>" method="POST" class="d-inline">
              <?php echo method_field('delete'); ?>
              <?php echo csrf_field(); ?>
              <button class="btn btn-danger btn-sm mb-3" onclick="return confirm('Anda yakin ingin menghapus Note ini?')"><i class="bi bi-trash"></i> Hapus</button>
          </form>
        <?php endif; ?>

      <table class="mb-3">
        <tr>
          <td class=" bold">Pemimpin </td>
          <td> : </td>
          <td><?php echo e($notes->pemimpin); ?> </td>
        </tr>
        <tr>
          <td>Tanggal </td>
          <td> : </td>
          <td>
            <?php echo e(App\Http\Controllers\NoteController::tanggal_indo($notes->tanggal, true)); ?>

            
          </td>
        </tr>
        <tr>
          <td class="align-baseline">Yang Hadir </td>
          <td class="align-baseline"> : </td>
          <td><?php echo e($notes->hadir); ?> </td>
        </tr>
        <tr>
          <td class="align-baseline">Keterangan </td>
          <td class="align-baseline"> : </td>
          <td><?php echo e($notes['keterangan']); ?> </td>
        </tr>
      </table>
      
      <h6 class="card-text mb-2">Pembahasan</h6>
      <div class="">
        <ol class="pl-3">
            <?php $__currentLoopData = $isi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="card-text">
                <?php echo $i['isi_note']; ?>

            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ol>
      </div>
    </div>
  </div>
            
      
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel-app\project1\resources\views/singlenote.blade.php ENDPATH**/ ?>