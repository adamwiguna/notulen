


<?php $__env->startSection('container'); ?>


    

    
    <?php if(auth()->user()->is_admin): ?>
        <?php echo $__env->make('note.nav.adminnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>        
    <?php else: ?>
        <?php echo $__env->make('note.nav.usernav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    <div class="cobg-white">
    
    <div class="bg-white">
        
        
        
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('search', \App\Models\Note::class)): ?>
        
        <div class="row ">
            <div class="col">
                <form action="/notes">
                    <div class="input-group mb-3 shadow-sm">
                        <input type="text" class="form-control" placeholder="Cari" name="cari" value="<?php echo e(request('cari')); ?>">
                        <div class="input-group-append">
                          <button class="btn btn-outline-secondary" type="submite">Cari</button>
                        </div>
                      </div>
                </form>
            </div>
        </div>    
        <?php endif; ?>
        

        <?php if($navnote == 'all'): ?>
            <?php echo $__env->make('note.nav.userNavDivisions', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>        
        <?php endif; ?>

        
        <div class="list-note bg-white">

            <?php if($notes->count()): ?>
          
            <?php $__currentLoopData = $notes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>              

                <div class="card mb-3 shadow-sm small <?php echo e((!count($note->readHistories->where('user_id', auth()->user()->id))) ? 'border-danger' : ''); ?>" >

                    <?php if($navnote != 'my'): ?>
                    <div class="card-header bg-secondary text-white small justify-content-between">
                        <div class=" d-flex justify-content-between">
                            <div>
                        <?php if($note->user): ?>
                            Oleh <a href="/users/<?php echo e($note->user->slug); ?>" class="text-decoration-none text-white"><?php echo e($note->user->name); ?></a>  
                     
                        <?php else: ?>
                            Ditulis oleh Anonim 
                        <?php endif; ?> 
                        <?php if($navnote == 'all' || $navnote == 'division'): ?>
                            <?php if(!count($note->readHistories)): ?>
                                <span class="badge bg-danger text-white ">BARU</span>
                            <?php endif; ?>
                        <?php endif; ?>
                        <?php if($navnote == 'new'): ?>
                            <span class="badge bg-danger text-white ">BARU</span>
                        <?php endif; ?>
                    </div>
                        <div>
                            <small><?php echo e($note->created_at->diffForHumans()); ?></small>
                          </div>
                      </div>
                    </div>
                    <?php endif; ?>

                    <a href="/notes/<?php echo e($note->slug); ?>" class="text-decoration-none text-reset">
                    <div class="card-body small">
                    <h6 class="card-title "> 
                        <?php echo e($note['judul']); ?>

                        <?php if(count($note->updateHistories)): ?>
                        <span class="badge bg-info text-white text-small">Diedit <?php echo e(count($note->updateHistories)); ?> kali</span>
                        <?php endif; ?>
                    </h6>

                   

                    <p class="card-subtitle  mb-2 "> <?php echo e($note->pemimpin); ?>, pada <?php echo e(App\Http\Controllers\NoteController::tanggal_indo($note->tanggal, true)); ?></p>

               
                    <?php if($navnote == 'trash' || $navnote == 'alltrash'): ?>  
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('restore', $note)): ?>
                            <a href="/notes/restore/<?php echo e($note->slug); ?>" class="btn btn-success btn-sm small" onclick="return confirm('Anda yakin ingin merestore Note ini?')">Restore Note</a>  
                        <?php endif; ?> 
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('forceDelete', $note)): ?>
                            <a href="/notes/forceDelete/<?php echo e($note->slug); ?>" class="btn btn-danger btn-sm" onclick="return confirm('Anda yakin ingin menghapus permanen Note ini?')">Delete Permanent</a>
                        <?php endif; ?>
                    <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $note)): ?>
                            <a href="/notes/<?php echo e($note['slug']); ?>/edit" class="btn btn-sm btn-info"><small> Ubah</small></a>  
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $note)): ?>
                            <form action="/notes/<?php echo e($note->id); ?>" method="POST" class="d-inline">
                                <?php echo method_field('delete'); ?>
                                <?php echo csrf_field(); ?>
                                <button class="btn btn-danger btn-sm" onclick="return confirm('Anda yakin ingin menghapus Note ini?')"><small>Hapus</small></button>
                            </form>
                        <?php endif; ?>
                </div>
                </a>

                <?php if($navnote == 'my'): ?>
                    <div class="card-footer text-muted">
                        <small><?php echo e($note->created_at->diffForHumans()); ?></small>
                    </div>
                    <?php endif; ?>
                </div>    
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
            Tidak ada Note
            <?php endif; ?>
            
            <div class="d-flex justify-content-center  mb-5">
                <?php echo e($notes->onEachSide(0)->links()); ?>

            </div>

    
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel-app\project1\resources\views/note.blade.php ENDPATH**/ ?>