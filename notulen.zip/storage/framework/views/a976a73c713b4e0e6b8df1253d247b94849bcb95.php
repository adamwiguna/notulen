
<ul class="nav nav-tabs justify-content-center mb-3">

        <li class="nav-item">
        <a class="nav-link <?php echo e(($navnote == 'my') ?  'active fw-bold '  : 'text-secondary'); ?>" href="/note/my">Saya</a>
        </li>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('viewNotesByDivision', \App\Models\Note::class)): ?>
            <li class="nav-item">
            <a class="nav-link <?php echo e(($navnote == 'division') ?  'active fw-bold '  : 'text-secondary'); ?>" href="/notes/division"><?php echo e(isset(auth()->user()->division->name) ? auth()->user()->division->name : ''); ?></a>
            </li>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('viewAllNotes', \App\Models\Note::class)): ?>
            <li class="nav-item">
            <a class="nav-link <?php echo e(($navnote == 'all') ?  'active fw-bold '  : 'text-secondary'); ?>"  href="/notes">Semua</a>
            </li>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('viewNewNotes', \App\Models\Note::class)): ?>
            <li class="nav-item">
            <a class="nav-link <?php echo e(($navnote == 'new') ?  'active fw-bold '  : 'text-secondary'); ?>"  href="/note/new">
                Baru
                <span class="badge bg-danger"><?php echo e(App\Http\Controllers\NoteController::countNewNotes()); ?></span>
            </a>
            </li>
        <?php endif; ?>

      
</ul>

<?php /**PATH E:\Laravel-app\project1\resources\views/note/nav/usernav.blade.php ENDPATH**/ ?>