
<ul class="nav nav-tabs justify-content-center">

    <?php if(auth()->user()->authorization_level >= 0): ?>
        <li class="nav-item">
        <a class="nav-link <?php echo e(($navnote == 'my') ?  'active fw-bold '  : 'text-secondary'); ?>" href="/note/my">Saya</a>
        </li>
        <?php if(auth()->user()->authorization_level >= 1): ?>
            <li class="nav-item">
            <a class="nav-link <?php echo e(($navnote == 'division') ?  'active fw-bold '  : 'text-secondary'); ?>" href="/notes/division">Bidang</a>
            </li>
            <?php if(auth()->user()->authorization_level >= 2): ?>
                <li class="nav-item">
                <a class="nav-link <?php echo e(($navnote == 'all') ?  'active fw-bold '  : 'text-secondary'); ?>"  href="/notes">Semua</a>
                </li>
                <?php if(auth()->user()->authorization_level >= 3): ?>
                    <li class="nav-item">
                    <a class="nav-link <?php echo e(($navnote == 'new') ?  'active fw-bold '  : 'text-secondary'); ?>"  href="/note/new">Baru</a>
                    </li>
                <?php endif; ?>
            <?php endif; ?>
        <?php endif; ?>

    <?php endif; ?>

    
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
        <li class="nav-item">
        <a class="nav-link <?php echo e(($navnote == 'trash') ?  'active fw-bold '  : 'text-secondary'); ?>" href="/note/trash">Trash</a>
        </li>  
        <li class="nav-item">
        <a class="nav-link <?php echo e(($navnote == 'alltrash') ?  'active fw-bold'  : 'text-secondary'); ?>" href="/note/alltrash">Trash</a>
        </li>  
    <?php endif; ?>
</ul><?php /**PATH E:\Laravel-app\project1\resources\views/user/nav.blade.php ENDPATH**/ ?>