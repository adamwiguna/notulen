



<?php $__env->startSection('container'); ?>

    
        

        <?php if(session()->has('success')): ?>
          <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>   
        <?php endif; ?>
        
        <div class="list-user">
            <table class="table table-sm table-borderless">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Nama</th>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', \App\Models\User::class)): ?>
                    <th scope="col">Aksi</th>
                    <?php endif; ?>
                  </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($loop->iteration); ?></th>
                            <td><a href="/users/<?php echo e($user['slug']); ?>" class="text-decoration-none text-dark"><?php echo e($user->name); ?></a></td>
                            <td>
                              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', \App\Models\User::class)): ?>
                                <a href="/user/<?php echo e($user['slug']); ?>/edit" class="btn btn-sm btn-info text-white"><i class="bi bi-pencil-square"></i></a> 
                              <?php endif; ?>
                              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', \App\Models\User::class)): ?>
                                <form action="/user/<?php echo e($user->slug); ?>" method="POST" class="d-inline">
                                  <?php echo method_field('delete'); ?>
                                  <?php echo csrf_field(); ?>
                                  <button class="btn btn-danger btn-sm" onclick="return confirm('Anda yakin ingin menghapus User ini?')"><i class="bi bi-trash"></i></button>
                                </form>
                              <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>    
        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel-app\project1\resources\views/user.blade.php ENDPATH**/ ?>