


<?php $__env->startSection('container'); ?>

<?php if(session()->has('success')): ?>

<?php endif; ?>




<div class="card mb-5">
    <div class="card-header">
      <ul class="nav nav-tabs card-header-tabs">
        <li class="nav-item">
          <a class="nav-link " href="/notes/<?php echo e($notes->slug); ?>">Note</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active " href="/notes/images/<?php echo e($notes->slug); ?>">Foto</a>
        </li>
        <li class="nav-item">
          <a class="nav-link " href="/notes/attendances/<?php echo e($notes->slug); ?>">Peserta</a>
        </li>
      </ul>
    </div>
    
 

    <div class="card-body">
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('addImages', $notes)): ?>
      <form action="/notes/images/simpan" method="POST" enctype="multipart/form-data" >
        <?php echo csrf_field(); ?>
        <div class="input-group input-group-sm mb-3">
          <input type="hidden"  name="note_id" id="" value="<?php echo e($notes->id); ?>">
          <input type="hidden"  name="note_slug" id="" value="<?php echo e($notes->slug); ?>">
          
          <div class=" d-flex">
            <input class="form-control form-control-sm" id="formFileSm" type="file" name="image[]" multiple accept="image/*">
            
            <button class="btn btn-info btn-sm" type="submit">Upload</button>
          </div>
      </div>
      </form>
      <?php endif; ?>

      <div class="row">
        <?php $__empty_1 = true; $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <a href="<?php echo e($image->image_url); ?>">
        <div class="col mx-auto col-lg-4">
            <div class="card mb-4 box-shadow mx-auto">
              <div style="">
                <img class="card-img-top " src="<?php echo e($image->image_url); ?>" >
              </div>
              <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                  <div class="btn-group">
                    <a href="<?php echo e($image->image_url); ?>"></a>
                      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('deleteImages', $notes)): ?>
                        <form action="/notes/images/<?php echo e($image->id); ?>" method="POST" class="d-inline">
                          <?php echo method_field('delete'); ?>
                          <?php echo csrf_field(); ?>
                          <button class="btn btn-sm btn-danger" onclick="return confirm('Anda yakin ingin menghapus Note ini?')"> <i class="bi bi-trash"></i> Hapus </button>
                        </form>
                      <?php endif; ?>
                    </div>
                  
                </div>
              </div>
            </div>
          </div>
        </a>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <p>Tidak Ada Foto</p>
          <?php endif; ?>
      </div>
 
    </div>

    
  </div>
            
      
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel-app\project1\resources\views/note/singlenote_images.blade.php ENDPATH**/ ?>