<ul class="nav nav-pills nav-justified mb-3">
    <?php $__currentLoopData = $divisions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $division): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li class="nav-item small">
      <a class="nav-link px-0 small text-decoration-none <?php echo e((isset($navnotebydivision)) ? (( $navnotebydivision == $division->id) ? 'active' : 'text-secondary') : ''); ?>" aria-current="page" href="/notes/division/<?php echo e($division->id); ?>"><?php echo e($division->name); ?></a>
    </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul><?php /**PATH E:\Laravel-app\project1\resources\views/note/nav/userNavDivisions.blade.php ENDPATH**/ ?>